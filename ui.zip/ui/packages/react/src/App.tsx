import Aside from '@react/layout/Aside';
import Header from '@react/layout/Header';
import qs from 'qs';
import { useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import Content from './layout/Content';
import { MODE, useMode } from './models/useMode';

const App = () => {
  const location = useLocation();
  const { changeMode } = useMode();

  useEffect(() => {
    const { view = MODE.BLOCK } = qs.parse(location.search, { ignoreQueryPrefix: true });
    changeMode(view as MODE);
  }, [changeMode, location.search]);

  return (
    <div>
      <Header />
      <div className="flex">
        <Aside />
        <Content />
      </div>
    </div>
  );
};

export default App;
