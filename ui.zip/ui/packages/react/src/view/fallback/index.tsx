import { Spin } from 'antd';

const Fallback = () => {
  return (
    <div className="spin h-screen w-screen">
      <Spin>
        <div className="spin h-screen w-screen flex justify-center items-center">
          {/* <img src={Res.LatsLogo} alt="" /> */}
        </div>
      </Spin>
    </div>
  );
};

export default Fallback;
