import { router } from '@react/router/index.tsx';
import Fallback from '@react/view/fallback';
import ReactDOM from 'react-dom/client';
import { RouterProvider } from 'react-router-dom';

import '@react/styles/index.scss';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <RouterProvider router={router} fallbackElement={<Fallback />} />,
);
