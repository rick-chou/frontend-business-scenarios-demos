import { useHeightModel } from '@react/model/useHeightModel';
import { routers } from '@react/router/build';
import { isEmpty } from 'lodash-es';
import { useNavigate } from 'react-router-dom';

const Aside = () => {
  const navigate = useNavigate();
  const { height } = useHeightModel();

  return (
    <aside className="flex flex-col overflow-hidden bg-white w-[320px] border-r" style={{ height }}>
      <nav className="flex flex-1 flex-col overflow-y-auto">
        {routers
          .filter(i => !isEmpty(i.children))
          .map(i => (
            <button
              key={i.path}
              type="button"
              onClick={() => {
                navigate(`/${i.path}`);
              }}
              className="action group focus-on-key relative h-14 shrink-0 !justify-between border-b px-5 text-gray-800">
              <span className="name capitalize">{i.path}</span>
              <span className="flex w-8 justify-center rounded bg-gray-200 px-2 py-0.5 text-sm text-gray-400 transition duration-100">
                {i.children?.length}
              </span>
            </button>
          ))}
      </nav>
    </aside>
  );
};

export default Aside;
