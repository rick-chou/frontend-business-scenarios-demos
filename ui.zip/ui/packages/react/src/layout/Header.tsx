import { CloseIcon, CodeIcon, CopyIcon, LeftArrowIcon, LinkIcon, PreviewIcon, RightArrowIcon } from '@base/assets/Icon';
import Button from '@base/components/Button';
import Show from '@base/components/Show';
import { MODE, useMode } from '@react/models/useMode';
import { capitalize, upperCase } from 'lodash-es';
import { name } from '../../package.json';

const Header = () => {
  const { mode, changeMode } = useMode();

  return (
    <header className="flex h-14 w-full">
      {/* left */}
      <div className="flex items-center border-b pl-5 border-r w-[320px]">
        <span className="font-semibold text-gray-800"> {upperCase(name)} </span>
      </div>

      {/* right */}
      <div className="flex flex-1 items-center justify-between gap-3 border-b pl-5 pr-4 lg:pr-5">
        <div className="flex items-center gap-3 lg:gap-4">
          <h2 className="font-semibold text-gray-800">
            <span> {capitalize(mode)} </span>
          </h2>
        </div>
        <Show when={mode !== MODE.BLOCK}>
          <div className="shrink-0">
            <span className="flex justify-center rounded bg-gray-100 px-2 py-0.5 text-xs text-gray-500">
              <span>1</span>
              <span className="mx-1">/</span>
              <span>4</span>
            </span>
          </div>
        </Show>
      </div>

      <Show when={mode !== MODE.BLOCK}>
        <nav className="flex shrink-0 divide-x border-l">
          <div
            className="relative"
            onClick={() => {
              changeMode(MODE.PREVIEW);
              window.history.pushState(null, '', `?view=preview`);
            }}>
            <Button icon={<PreviewIcon />} title="preview" />
            {mode === MODE.PREVIEW && <span className="active-indicator bg-violet-400"></span>}
          </div>
          <div
            className="relative"
            onClick={() => {
              changeMode(MODE.CODE);
              window.history.pushState(null, '', `?view=code`);
            }}>
            <Button icon={<CodeIcon />} title="code" />
            {mode === MODE.CODE && <span className="active-indicator bg-violet-400"></span>}
          </div>
          <Button icon={<CopyIcon />} showActive title="copy code" />
          <Button icon={<LinkIcon />} showActive title="copy link" />
          <Button icon={<LeftArrowIcon />} title="previous" />
          <Button icon={<RightArrowIcon />} title="next" />
          <Button icon={<CloseIcon />} title="close" />
        </nav>
      </Show>
    </header>
  );
};

export default Header;
