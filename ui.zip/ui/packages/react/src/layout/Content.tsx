import { useHeightModel } from '@react/model/useHeightModel';
import { throttle } from 'lodash-es';
import { useEffect, useRef } from 'react';
import { useLocation, useOutlet } from 'react-router-dom';
import { CSSTransition, SwitchTransition } from 'react-transition-group';

const Content = () => {
  const { height, updateHeight } = useHeightModel();
  const location = useLocation();
  const currentOutlet = useOutlet();
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const fn = throttle(() => {
      updateHeight();
    }, 300);

    window.addEventListener('resize', fn);

    return () => {
      window.removeEventListener('resize', fn);
    };
  }, [updateHeight]);

  return (
    <div className="overflow-y-auto px-4 flex-1" style={{ height }}>
      <SwitchTransition>
        <CSSTransition key={location.pathname} nodeRef={ref} timeout={300} classNames="content" unmountOnExit>
          {() => (
            <div className="content" ref={ref}>
              {currentOutlet}
            </div>
          )}
        </CSSTransition>
      </SwitchTransition>
    </div>
  );
};

export default Content;
