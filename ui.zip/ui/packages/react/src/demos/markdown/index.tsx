import Preview from '@base/components/Preview';

const Markdown = () => {
  return (
    <div className="grid gap-6 grid-cols-3">
      <Preview>111</Preview>
      <Preview />
      <Preview />
      <Preview />
      <Preview />
      <Preview />
      <Preview />
      <Preview />
    </div>
  );
};

export default Markdown;
