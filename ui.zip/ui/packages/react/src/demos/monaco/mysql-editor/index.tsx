const MysqlEditor = () => {
  return <div>Mysql</div>;
};

export default MysqlEditor;
