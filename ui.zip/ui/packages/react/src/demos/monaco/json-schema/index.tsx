import Editor, { useMonaco } from '@monaco-editor/react';
import { useHeightModel } from '@react/model/useHeightModel';
import { useEffect } from 'react';

const SUMI_OVERFLOW_WIDGETS_CONTAINER_ID = 'sumi-overflow-widgets-container';

const JsonSchema = () => {
  const { height } = useHeightModel();
  const monaco = useMonaco();

  useEffect(() => {
    if (monaco) {
      const overflowWidgetsContainer = document.createElement('div');
      overflowWidgetsContainer.className = 'monaco-editor';
      overflowWidgetsContainer.id = SUMI_OVERFLOW_WIDGETS_CONTAINER_ID;
      document.body.appendChild(overflowWidgetsContainer);

      monaco.languages.json.jsonDefaults.setDiagnosticsOptions({
        validate: true,
        schemas: [
          {
            uri: 'custom-uri',
            schema: {
              type: 'object',
              description: 'sheet tag of the tax project',
              properties: {
                param: {
                  description: 'param 1',
                  type: 'string',
                },
                name: {
                  description: 'name  description',
                  type: 'string',
                },
                prices: {
                  description: 'price of the goods',
                  type: 'number',
                  exclusiveMinimum: 0,
                },
              },
              required: ['param', 'name', 'prices'],
            },
          },
        ],
      });
    }
  }, [monaco]);

  return (
    <div>
      <Editor
        height={height}
        language="json"
        options={{ overflowWidgetsDomNode: document.getElementById(SUMI_OVERFLOW_WIDGETS_CONTAINER_ID)! }}
      />
    </div>
  );
};

export default JsonSchema;
