import Preview from '@base/components/Preview';
import { routes } from '@react/router';
import { matchRoutes, Outlet, useLocation } from 'react-router-dom';

const Demo = () => {
  const location = useLocation();

  const currentRoute = matchRoutes(routes, location)?.at(-1)?.route;

  return (
    <div>
      <div className="grid gap-6 grid-cols-3">
        {currentRoute?.children?.map(i => {
          return (
            <Preview key={i.path} path={`/${currentRoute.path}/${i.path}`}>
              {i.path}
            </Preview>
          );
        })}
      </div>
      <Outlet />
    </div>
  );
};

export default Demo;
