import { toUpper } from 'lodash-es';
import { create } from 'zustand';

export enum MODE {
  PREVIEW = 'PREVIEW',
  CODE = 'CODE',
  BLOCK = 'BLOCK',
}

type ModelType = {
  mode: MODE;
  changeMode: (mode: MODE) => void;
};

export const useMode = create<ModelType>(set => ({
  mode: MODE.BLOCK,
  changeMode(mode: MODE) {
    set(() => ({ mode: toUpper(mode) as MODE }));
  },
}));
