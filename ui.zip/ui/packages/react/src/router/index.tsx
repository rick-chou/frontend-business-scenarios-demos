import App from '@react/App';
import { createBrowserRouter, redirect, type RouteObject } from 'react-router-dom';
import { routers } from './build';

export const routes: RouteObject[] = [
  {
    path: '',
    element: <App />,
    children: routers,
  },
  {
    path: '*',
    loader() {
      return redirect('/');
    },
  },
];

export const router = createBrowserRouter(routes, { basename: window.__MICRO_APP_BASE_ROUTE__ || '/' });
