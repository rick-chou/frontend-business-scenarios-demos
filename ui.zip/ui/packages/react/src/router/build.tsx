import { filter, forEach, forIn } from 'lodash-es';
import { type FC } from 'react';
import { type RouteObject } from 'react-router-dom';

type Component = {
  default: FC;
};

type Module = Record<string, () => Promise<Component>>;

const modules = import.meta.glob(['@react/demos/**/index.tsx']) as Module;

const buildRouter = () => {
  const dirSet = new Set<string>();

  const routes: RouteObject[] = [];

  forIn(modules, (_, path) => {
    const p = path.substring(path.indexOf('demos')).replace('demos/', '');
    dirSet.add(p.substring(0, p.indexOf('/')));
  });

  dirSet.forEach(i => {
    const children: RouteObject[] = [];

    const cModules = filter(Object.keys(modules), v => {
      return !v.includes(`${i}/index.tsx`) && v.includes(i);
    });

    forEach(cModules, v => {
      children.push({
        path: v.split('/').at(-2),
        lazy: async () => ({ Component: (await modules[v]()).default }),
      });
    });
    routes.push({
      path: i,
      lazy: async () => ({ Component: (await import(`@react/demos/Index`)).default }),
      children,
    });
  });

  return routes;
};

export const routers = buildRouter();
