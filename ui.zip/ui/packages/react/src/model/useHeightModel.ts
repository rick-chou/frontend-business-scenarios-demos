import { create } from 'zustand';

type ModelType = {
  height: number;
  updateHeight: () => void;
};

const calcHeight = () => document.body.clientHeight - 56 * (1 + (window.__MICRO_APP_ENVIRONMENT__ ? 1 : 0));

export const useHeightModel = create<ModelType>(set => ({
  height: calcHeight(),
  updateHeight() {
    set(() => ({ height: calcHeight() }));
  },
}));
