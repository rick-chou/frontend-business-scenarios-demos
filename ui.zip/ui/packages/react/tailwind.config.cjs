/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./index.html', './src/**/*.tsx', '../base/src/**/*.tsx'],
  theme: {
    extend: {
      colors: {
        gray: {
          700: 'rgb(63 63 70)',
        },
        violet: {
          400: 'rgb(167 139 250)',
        },
      },
    },
  },
  darkMode: 'selector',
  plugins: [],
  corePlugins: {
    preflight: true,
  },
};
