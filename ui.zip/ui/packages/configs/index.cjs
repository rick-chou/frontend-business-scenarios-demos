const merge = require("deepmerge");

function mixinConfig(defaultConfig) {
  return (config) => merge(config, defaultConfig);
}

module.exports = {
  tailwind: mixinConfig(require("./tailwind/index.cjs")),
  postcss: mixinConfig(require("./postcss/index.cjs")),
  prettier: mixinConfig(require("./prettier/index.cjs")),
  eslint: {
    react: mixinConfig(require("./eslint/react/index.cjs")),
  },
};
