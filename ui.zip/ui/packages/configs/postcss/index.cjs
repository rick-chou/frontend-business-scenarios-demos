/** @type {import('postcss').AcceptedPlugin} */
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};
