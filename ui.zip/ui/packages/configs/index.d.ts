import { type ESLintConfig } from "eslint-define-config";
import { type Options as PrettierConfig } from "prettier";
import { type Config as TailwindConfig } from "tailwindcss";
import { type AcceptedPlugin as PostcssConfig } from "postcss";

type ConfigWrapper<T = any> = (config: T) => T;

declare module "@rick-demo/configs" {
  export const tailwind: ConfigWrapper<TailwindConfig>;
  export const postcss: ConfigWrapper<PostcssConfig>;
  export const prettier: ConfigWrapper<PrettierConfig>;
  export const eslint: {
    react: ConfigWrapper<ESLintConfig>;
  };
}
