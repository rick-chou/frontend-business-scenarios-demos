/** @type {import('tailwindcss').Config} */
module.exports = require('@rick-demo/configs');
