import { Link } from 'react-router-dom';
import { version } from '../package.json';
import { GithubIcon, MoonIcon, QuestionIcon, ReactIcon, SunIcon, TerminalIcon, VueIcon } from './assets/Icon';
import { useThemeModel } from './model/useThemeModel';

const Header = () => {
  const { theme, toggleTheme } = useThemeModel(state => state);
  return (
    <header className="flex h-14 overflow-hidden bg-white dark:bg-gray-700 shrink-0">
      <div className="flex flex-1 items-center border-b pl-5">
        <div className="relative flex items-center gap-1.5">
          <TerminalIcon />
          <div className="text-lg font-bold text-gray-800 dark:text-gray-100"> Rick {version} </div>
        </div>
      </div>
      <div className="flex">
        <Link to={'/react/'}>
          <button type="button" className="action focus-on-key h-14 w-14 border-l border-b">
            <ReactIcon />
          </button>
        </Link>
        <Link to={'/vue/'}>
          <button type="button" className="action focus-on-key h-14 w-14 border-l border-b">
            <VueIcon />
          </button>
        </Link>
        <button type="button" className="action focus-on-key h-14 w-14 border-l border-b">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="currentColor"
            className="inline-block h-auto w-6">
            <path
              fillRule="evenodd"
              clipRule="evenodd"
              d="M18 4.65H6C5.25442 4.65 4.65 5.25442 4.65 6V18C4.65 18.7456 5.25442 19.35 6 19.35H18C18.7456 19.35 19.35 18.7456 19.35 18V6C19.35 5.25442 18.7456 4.65 18 4.65ZM6 3C4.34315 3 3 4.34315 3 6V18C3 19.6569 4.34315 21 6 21H18C19.6569 21 21 19.6569 21 18V6C21 4.34315 19.6569 3 18 3H6Z"></path>
            <circle cx="8.5" cy="8.5" r="1.5"></circle>
            <circle cx="8.5" cy="15.5" r="1.5"></circle>
            <circle cx="15.5" cy="8.5" r="1.5"></circle>
            <circle cx="15.5" cy="15.5" r="1.5"></circle>
          </svg>
        </button>
        <button type="button" className="action focus-on-key hidden h-14 w-14 border-l border-b xl:flex">
          <QuestionIcon />
        </button>
        <button
          onClick={toggleTheme}
          type="button"
          className="action focus-on-key h-14 w-14 border-l border-b hover:text-indigo-500 dark:hover:text-amber-400">
          <GithubIcon />
        </button>
        <button
          onClick={toggleTheme}
          type="button"
          className="action focus-on-key h-14 w-14 border-l border-b hover:text-indigo-500 dark:hover:text-amber-400">
          {theme === 'dark' ? <SunIcon /> : <MoonIcon />}
        </button>
      </div>
    </header>
  );
};

export default Header;
