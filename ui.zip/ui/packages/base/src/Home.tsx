const Home = () => {
  return <div>HOME</div>;
};

export default Home;
