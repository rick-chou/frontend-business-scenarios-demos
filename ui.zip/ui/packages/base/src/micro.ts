import microApp from '@micro-zoe/micro-app';

microApp.start({
  'disable-memory-router': true,
  iframe: true,
  'keep-alive': true,
  /**
   * @issue https://github.com/micro-zoe/micro-app/issues/253
   */
  disableScopecss: true,
});

export enum MICRO_APP {
  'REACT_APP' = 'REACT_APP',
  'VUE_APP' = 'VUE_APP',
}
