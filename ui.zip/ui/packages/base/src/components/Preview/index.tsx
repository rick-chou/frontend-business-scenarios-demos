import { CodeIcon, CopyIcon, PreviewIcon } from '@base/assets/Icon';
import { type FC, type PropsWithChildren } from 'react';
import { useNavigate } from 'react-router-dom';
import Button from '../Button';

const Preview: FC<PropsWithChildren<{ path: string }>> = ({ children, path }) => {
  const navigate = useNavigate();
  return (
    <article className="py-4">
      <div className="flex h-64 flex-col border bg-gray-50">
        <div className="flex flex-1 items-center justify-center overflow-hidden p-8">
          <div className="uppercase font-sans font-black italic">{children}</div>
        </div>
        <div className="flex h-12 shrink-0 items-center justify-end border-t bg-white">
          <nav className="flex shrink-0 divide-x border-l">
            <Button
              icon={<PreviewIcon />}
              className="action focus-on-key relative !h-12 !w-12 border-b"
              onClick={() => {
                navigate(`${path}?view=preview`);
              }}
            />
            <Button
              icon={<CodeIcon />}
              className="action focus-on-key relative !h-12 !w-12 border-b"
              onClick={() => {
                navigate(`${path}?view=code`);
              }}
            />
            <Button icon={<CopyIcon />} className="!hidden action focus-on-key relative !h-12 !w-12 border-b" />
          </nav>
        </div>
        <div className="focus-base pointer-events-none absolute inset-0 group-focus:ring-2"></div>
      </div>
    </article>
  );
};

export default Preview;
