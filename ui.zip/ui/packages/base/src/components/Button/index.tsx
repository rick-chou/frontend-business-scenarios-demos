import { CheckIcon } from '@base/assets/Icon';
import { useRef, useState, type ButtonHTMLAttributes, type FC, type ReactNode } from 'react';
import { CSSTransition, SwitchTransition } from 'react-transition-group';

import './index.scss';

type ButtonProps = {
  icon: ReactNode;
  showActive?: boolean;
  onClick?: () => void;
} & ButtonHTMLAttributes<HTMLButtonElement>;

const Button: FC<ButtonProps> = ({ icon, showActive = false, onClick, ...attrs }) => {
  const [active, setActive] = useState(false);
  const iconRef = useRef<HTMLSpanElement>(null);
  const checkRef = useRef<HTMLSpanElement>(null);
  const nodeRef = active ? checkRef : iconRef;

  return (
    <button
      {...attrs}
      className={`fe-btn-container action focus-on-key h-14 w-14 border-b ${attrs.className}`}
      type="button"
      onClick={() => {
        onClick?.();
        if (showActive) {
          setActive(true);
        }

        setTimeout(() => {
          setActive(false);
        }, 400);
      }}>
      <SwitchTransition mode={'out-in'}>
        <CSSTransition
          key={`${active}`}
          nodeRef={nodeRef}
          addEndListener={done => {
            nodeRef.current?.addEventListener('transitionend', done, false);
          }}
          classNames="fade">
          <span ref={nodeRef}>{active ? <CheckIcon /> : icon}</span>
        </CSSTransition>
      </SwitchTransition>
    </button>
  );
};

export default Button;
