/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly ENV_REACT_APP_URL: string;
  readonly ENV_VUE_APP_URL: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
