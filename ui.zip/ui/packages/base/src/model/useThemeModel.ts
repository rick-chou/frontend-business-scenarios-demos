import { message } from 'antd';
import { create } from 'zustand';

type Theme = 'light' | 'dark';

type ModelType = {
  theme: Theme;
  toggleTheme: () => void;
};

export const useThemeModel = create<ModelType>(set => ({
  theme: 'light',
  toggleTheme() {
    void message.open({ content: '😅 It seems you want to change the theme, but nothing happened.' });
    // set(state => ({ theme: state.theme === 'light' ? 'dark' : 'light' }));
    set({ theme: 'light' });
  },
}));
