import { Route, Routes } from 'react-router-dom';
import Header from './Header';
import Home from './Home';
import { MICRO_APP } from './micro';
import { useThemeModel } from './model/useThemeModel';

function App() {
  const { theme } = useThemeModel(state => state);

  return (
    <div className={theme}>
      <div className="theme-transition h-screen select-none overflow-hidden">
        <Header />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route
            path="/react/*"
            element={
              <micro-app name={MICRO_APP.REACT_APP} url={import.meta.env.ENV_REACT_APP_URL} baseroute="/react/" />
            }
          />
          <Route path="/vue/*" element={<micro-app name={MICRO_APP.VUE_APP} url={import.meta.env.ENV_VUE_APP_URL} />} />
        </Routes>
      </div>
    </div>
  );
}

export default App;
