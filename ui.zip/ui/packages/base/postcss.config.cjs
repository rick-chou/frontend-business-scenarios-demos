module.exports = require('@rick-demo/configs/tailwind/index.cjs').postcss();
